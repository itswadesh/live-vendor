
import WebFont from 'webfontloader'

const options = {"google":{"families":["Inter:400,700&display=swap"]}}

WebFont.load(options)
