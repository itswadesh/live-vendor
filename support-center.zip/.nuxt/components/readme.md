# Discovered Components

This is an auto-generated list of components discovered by [nuxt/components](https://github.com/nuxt/components).

You can directly use them in pages and other components without the need to import them.

**Tip:** If a component is conditionally rendered with `v-if` and is big, it is better to use `Lazy` or `lazy-` prefix to lazy load.

- `<HelpAccount1>` | `<help-account1>` (components/Help/Account1.vue)
- `<HelpAccount2>` | `<help-account2>` (components/Help/Account2.vue)
- `<HelpAccount3>` | `<help-account3>` (components/Help/Account3.vue)
- `<HelpBox>` | `<help-box>` (components/Help/Box.vue)
- `<HelpHeading>` | `<help-heading>` (components/Help/Heading.vue)
