import Vue from 'vue'
import { wrapFunctional } from './index'

const components = {
  HelpAccount1: () => import('../..\\components\\Help\\Account1.vue' /* webpackChunkName: "components/help-account1" */).then(c => wrapFunctional(c.default || c)),
  HelpAccount2: () => import('../..\\components\\Help\\Account2.vue' /* webpackChunkName: "components/help-account2" */).then(c => wrapFunctional(c.default || c)),
  HelpAccount3: () => import('../..\\components\\Help\\Account3.vue' /* webpackChunkName: "components/help-account3" */).then(c => wrapFunctional(c.default || c)),
  HelpBox: () => import('../..\\components\\Help\\Box.vue' /* webpackChunkName: "components/help-box" */).then(c => wrapFunctional(c.default || c)),
  HelpHeading: () => import('../..\\components\\Help\\Heading.vue' /* webpackChunkName: "components/help-heading" */).then(c => wrapFunctional(c.default || c))
}

for (const name in components) {
  Vue.component(name, components[name])
  Vue.component('Lazy' + name, components[name])
}
