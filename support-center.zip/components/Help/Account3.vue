<template>
  <section class="my-10">
    <!-- Account management start  -->
    <div>
      <h3 class="text-lg font-semibold tracking-wide text-center text-gray-800">
        Account Management
      </h3>
    </div>
    <div>
      <p class="my-2 text-sm text-center text-gray-600">
        Find out easy ways and tips to manage you account section always
      </p>
    </div>
    <!-- White box start  -->

    <div
      class="w-full p-6 mx-auto my-5 text-gray-800 bg-white rounded-md shadow-md sm:w-5/6"
    >
      <!-- How can I change my email id using same account and mobile number section start  -->
      <div class="flex justify-between">
        <h4 class="text-sm font-semibold tracking-wide text-gray-800">
          How can I change my email id using same account and mobile number
        </h4>
        <svg
          xmlns="http://www.w3.org/2000/svg"
          class="w-5 h-5 cursor-pointer"
          viewBox="0 0 20 20"
          fill="currentColor"
        >
          <path
            fill-rule="evenodd"
            d="M5 10a1 1 0 011-1h8a1 1 0 110 2H6a1 1 0 01-1-1z"
            clip-rule="evenodd"
          />
        </svg>
      </div>

      <div class="p-5 text-sm text-gray-600">
        <ul class="list-disc">
          <li class="text-sm">
            You can update your account details by going to Account Recovery.
            For that, you will need to enter your old mobile number and go to
            the OTP page. You will find an option "Get Help" there to recover
            your account
          </li>
          <li class="my-3">
            Alternate Mobile Number is another mobile number that can be used to
            gain access to your account if you loose your login mobile number.
          </li>
          <li>
            Account recovery is the process of getting access to your account in
            case you have changed or lost your mobile number and did not change
            the mobile number on your Tablez account before you lost that
            number.
          </li>
        </ul>
      </div>
      <!-- How can I change my email id using same account and mobile number section end -->
      <!-- Was this answer Really helpful? section start  -->
      <div class="px-3 pb-3 border-b border-gray-500">
        <div class="flex items-center">
          <h6 class="text-sm font-semibold text-gray-800">
            Was this answer Really helpful?
          </h6>
          <div class="flex items-center">
            <div
              class="ml-4 border border-gray-800 rounded-full cursor-pointer hover:bg-gray-200"
            >
              <img class="w-6 h-6 m-1" src="/a/t-up.svg" alt="" />
            </div>
            <div
              class="ml-4 border border-gray-800 rounded-full cursor-pointer hover:bg-gray-200"
            >
              <img class="w-6 h-6 m-1" src="/a/t-down.svg" alt="" />
            </div>
          </div>
        </div>
        <a
          href="#"
          class="text-sm underline text-primary-500 hover:text-primary-200"
          >Contact Us</a
        >
      </div>
      <!-- Was this answer Really helpful? section end -->
      <div
        class="flex justify-between pb-3 my-4 text-sm border-b border-gray-500"
      >
        <p>How can I Reset my password without using email authentication</p>
        <div>
          <svg
            xmlns="http://www.w3.org/2000/svg"
            class="w-6 h-6 cursor-pointer hover:text-black"
            fill="none"
            viewBox="0 0 24 24"
            stroke="currentColor"
          >
            <path
              stroke-linecap="round"
              stroke-linejoin="round"
              stroke-width="2"
              d="M12 6v6m0 0v6m0-6h6m-6 0H6"
            />
          </svg>
        </div>
      </div>
      <div class="flex justify-between mt-4 text-sm">
        <p>How can I Reset my password without using email authentication</p>
        <div>
          <svg
            xmlns="http://www.w3.org/2000/svg"
            class="w-6 h-6 cursor-pointer hover:text-black"
            fill="none"
            viewBox="0 0 24 24"
            stroke="currentColor"
          >
            <path
              stroke-linecap="round"
              stroke-linejoin="round"
              stroke-width="2"
              d="M12 6v6m0 0v6m0-6h6m-6 0H6"
            />
          </svg>
        </div>
      </div>
    </div>
    <!-- White box start  -->
    <!-- Account management end -->
  </section>
</template>

<script>
export default {};
</script>

<style>
</style>