<template>
  <section>
    <!-- Boxes start  -->
    <div class="my-2 md:m-5">
      <div class="flex flex-wrap justify-center">
        <div
          class="w-full px-4 py-6 my-2 text-gray-700 transition duration-300 bg-white border rounded-sm shadow-md cursor-pointer hover:shadow md:m-2 md:w-40 h-28 hover:text-primary-500 hover:border-primary-500 boredr-black"
        >
          <img class="h-6 mx-auto" src="/a/shuttle.svg" alt="" />
          <p class="mt-3 text-xs text-center whitespace-no-wrap">
            Getting Started
          </p>
        </div>
        <div
          class="w-full px-4 py-6 my-2 text-gray-700 transition duration-300 bg-white border rounded-sm shadow-md cursor-pointer hover:shadow md:m-2 md:w-40 h-28 hover:text-primary-500 hover:border-primary-500 boredr-black"
        >
          <img class="h-6 mx-auto" src="/a/refund.svg" alt="" />
          <p class="mt-3 text-xs text-center whitespace-no-wrap">
            Returns and Refunds
          </p>
        </div>
        <div
          class="w-full px-4 py-6 my-2 text-gray-700 transition duration-300 bg-white border rounded-sm shadow-md cursor-pointer hover:shadow md:m-2 md:w-40 h-28 hover:text-primary-500 hover:border-primary-500 boredr-black"
        >
          <img class="h-6 mx-auto" src="/a/payment.svg" alt="" />
          <p class="mt-3 text-xs text-center whitespace-no-wrap">
            Payments and Delivery
          </p>
        </div>
        <div
          class="w-full px-4 py-6 my-2 text-gray-700 transition duration-300 bg-white border rounded-sm shadow-md cursor-pointer hover:shadow md:m-2 md:w-40 h-28 hover:border-primary-500 hover:text-primary-500 boredr-black"
        >
          <img class="h-6 mx-auto" src="/a/account.svg" alt="" />
          <p class="mt-3 text-xs text-center whitespace-no-wrap">
            Account Management
          </p>
        </div>
        <div
          class="w-full px-4 py-6 my-2 text-gray-700 transition duration-300 bg-white border rounded-sm shadow-md cursor-pointer hover:shadow md:m-2 md:w-40 h-28 hover:text-primary-500 hover:border-primary-500 boredr-black"
        >
          <img class="h-6 mx-auto" src="/a/query.svg" alt="" />
          <p class="mt-3 text-xs text-center whitespace-no-wrap">Top Queries</p>
        </div>
      </div>
    </div>
    <!-- Boxes end -->
  </section>
</template>

<script>
export default {};
</script>

<style>
</style>