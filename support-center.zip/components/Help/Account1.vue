<template>
  <section class="my-10">
    <!-- Account management start  -->
    <div>
      <h3 class="text-lg font-semibold tracking-wide text-center text-gray-800">
        Account Management
      </h3>
    </div>
    <div>
      <p class="my-2 text-sm text-center text-gray-600">
        Find out easy ways and tips to manage you account section always
      </p>
    </div>
    <!-- White box start  -->
    <div
      class="w-full p-6 mx-auto my-5 text-gray-800 bg-white rounded-md shadow-md sm:w-5/6"
    >
      <div class="flex justify-between pb-3 text-sm border-b border-gray-500">
        <p>How can I change my email id using same account and mobile number</p>
        <div>
          <svg
            xmlns="http://www.w3.org/2000/svg"
            class="w-6 h-6 cursor-pointer hover:text-black"
            fill="none"
            viewBox="0 0 24 24"
            stroke="currentColor"
          >
            <path
              stroke-linecap="round"
              stroke-linejoin="round"
              stroke-width="2"
              d="M12 6v6m0 0v6m0-6h6m-6 0H6"
            />
          </svg>
        </div>
      </div>
      <div
        class="flex justify-between pb-3 my-4 text-sm border-b border-gray-500"
      >
        <p>How can I Reset my password without using email authentication</p>
        <div>
          <svg
            xmlns="http://www.w3.org/2000/svg"
            class="w-6 h-6 cursor-pointer hover:text-black"
            fill="none"
            viewBox="0 0 24 24"
            stroke="currentColor"
          >
            <path
              stroke-linecap="round"
              stroke-linejoin="round"
              stroke-width="2"
              d="M12 6v6m0 0v6m0-6h6m-6 0H6"
            />
          </svg>
        </div>
      </div>
      <div class="flex justify-between text-sm">
        <p>
          Can I able to delete my account history Information and old passwords
        </p>
        <div>
          <svg
            xmlns="http://www.w3.org/2000/svg"
            class="w-6 h-6 cursor-pointer hover:text-black"
            fill="none"
            viewBox="0 0 24 24"
            stroke="currentColor"
          >
            <path
              stroke-linecap="round"
              stroke-linejoin="round"
              stroke-width="2"
              d="M12 6v6m0 0v6m0-6h6m-6 0H6"
            />
          </svg>
        </div>
      </div>
    </div>
    <!-- White box start  -->
    <!-- Account management end -->
  </section>
</template>

<script>
export default {};
</script>

<style>
</style>