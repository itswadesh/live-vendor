<template>
  <div
    class="flex flex-col w-full min-h-screen font-sans antialiased text-gray-900 bg-gray-100"
  >
    <nuxt />
  </div>
</template>
